[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/mLNYV8nm)
![1](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/2d791443-4ae5-472d-8333-e177e660c199)
![3](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/a5af9dbe-a52c-48e0-96b0-818fc116b7a4)
![4](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/e522aeaa-1769-4a96-86b4-a1ce8206d48c)
![7](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/aa3da2f2-8925-4ffb-8f7e-6e5be1681645)
![8](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/5b93a457-4586-4ac2-bf98-d20802478e4b)
![8-1](https://github.com/wsu-cs540-fall2023/cs-540-hw-1-R246N642/assets/123512126/c4f82761-80b5-4ad9-86e1-0f36d03e83fe)


